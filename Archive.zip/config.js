var server_domain = 'http://agrorunner.com';
var secret_key = "fb5e77f2b23945ce9cdfa9093b457fa2";
var wordpress = false;


