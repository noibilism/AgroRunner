var server_domain = 'http://callmycabwp.com';
var secret_key = "My_key";
var wordpress = true;


